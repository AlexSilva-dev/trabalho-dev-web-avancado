package com.uff.trabalhodevwebavancado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabalhoDevWebAvancadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
