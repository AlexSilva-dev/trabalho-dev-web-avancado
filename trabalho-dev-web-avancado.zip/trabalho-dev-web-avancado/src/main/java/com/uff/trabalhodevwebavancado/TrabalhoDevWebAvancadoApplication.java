package com.uff.trabalhodevwebavancado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrabalhoDevWebAvancadoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrabalhoDevWebAvancadoApplication.class, args);
	}

}
